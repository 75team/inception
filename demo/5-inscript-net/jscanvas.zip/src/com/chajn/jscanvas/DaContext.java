package com.chajn.jscanvas;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.SurfaceHolder;

/**
 * Created by liupengke on 15/3/20.
 */
public class DaContext{
    private Paint paint;
    private SurfaceHolder holder;
    public Boolean isRun = false;
    public DaContext(SurfaceHolder holder){
        this.holder = holder;
        paint = new Paint();
        paint.setColor(Color.RED);
    }


    public void setFillStyle(int a, int r, int g, int b){
        paint.setARGB(a, r, g, b);
    }
    public void fillRect(float x, float y, float w, float h){
//    	System.out.println("222222333");
        Canvas canvas = holder.lockCanvas();
        RectF r = new RectF(x, y, x+w, y+h);
        canvas.drawRect(r, paint);
        holder.unlockCanvasAndPost(canvas);
    }
    public void sf(SurfaceHolder h2){
      Canvas canvas = h2.lockCanvas();
      Paint paint = new Paint();
      paint.setColor(Color.RED);
      RectF r = new RectF(1,2, 222, 333);
      canvas.drawRect(r, paint);
      h2.unlockCanvasAndPost(canvas);
    }
}
