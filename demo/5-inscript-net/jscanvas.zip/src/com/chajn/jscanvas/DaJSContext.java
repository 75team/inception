package com.chajn.jscanvas;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.SurfaceHolder;

/**
 * Created by liupengke on 15/3/20.
 */
public class DaJSContext extends ScriptableObject {
	private Paint paint;
	private SurfaceHolder holder;

	public DaJSContext() {
	}

	public static Scriptable jsConstructor(Context cx, Object[] args,
			Function ctorObj, boolean inNewExpr) {
		DaJSContext dc = new DaJSContext();
		if (args.length == 0 || args[0] == Context.getUndefinedValue()) {
			dc.paint = null;
			dc.holder = null;
		} else {
			dc.holder = (SurfaceHolder) Context.jsToJava(args[0], SurfaceHolder.class);
			dc.paint = new Paint();
			dc.paint.setColor(Color.RED);
		}
		return dc;
	}

	public static void jsFunction_setFillStyle(Context cx, Scriptable thisObj,
            Object[] args, Function funObj) {
		DaJSContext dc = checkInstance(thisObj);
		int a = (Integer) Context.jsToJava(args[0], Integer.class); 
		int r = (Integer) Context.jsToJava(args[1], Integer.class); 
		int g = (Integer) Context.jsToJava(args[2], Integer.class); 
		int b = (Integer) Context.jsToJava(args[3], Integer.class); 
		dc.paint.setARGB(a, r, g, b);
	}

	public static void jsFunction_fillRect(Context cx, Scriptable thisObj,
            Object[] args, Function funObj) {
		DaJSContext dc = checkInstance(thisObj);
		Canvas canvas = dc.holder.lockCanvas();
		float x = (Integer) Context.jsToJava(args[0], Integer.class); 
		float y = (Integer) Context.jsToJava(args[1], Integer.class); 
		float w = (Integer) Context.jsToJava(args[2], Integer.class); 
		float h = (Integer) Context.jsToJava(args[3], Integer.class); 
		RectF r = new RectF(x, y, x + w, y + h);
		canvas.drawRect(r, dc.paint);
		dc.holder.unlockCanvasAndPost(canvas);
	}

	@Override
	public String getClassName() {
		// TODO Auto-generated method stub
		return "DaJSContext";
	}
	
	private static DaJSContext checkInstance(Scriptable obj) {
		if (obj == null || !(obj instanceof DaJSContext)) {
			throw Context.reportRuntimeError("called on incompatible object");
		}
		return (DaJSContext) obj;
	}
}
