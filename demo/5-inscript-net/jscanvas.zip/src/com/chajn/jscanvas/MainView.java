package com.chajn.jscanvas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import org.apache.http.util.EncodingUtils;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

import com.chajn.jscanvas.InScript;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by liupengke on 15/3/19.
 */
public class MainView extends SurfaceView implements SurfaceHolder.Callback {
    private SurfaceHolder holder;
//    private RenderThread render;
    public MainView(Context context){
        super(context);
        
        holder = getHolder();
        holder.addCallback(this);
        

        
//        DaContext dc = new DaContext(holder);
        //dc.setFillStyle(1, 1, 1, 1);
        //dc.fillRect(22, 33, 300, 400);
        
//        inScript.run();
//        inScript.putObject("Holder", holder);
//        inScript.setObject("DaContext", dc);

    }
    @Override
    public void surfaceCreated(SurfaceHolder holder){
//    	 System.out.println("init222");
         DaContext dc = new DaContext(holder);
         InScript inScript = new InScript();  
//         inScript.putObject("DaContext", dc);
         inScript.putObject("Holder", holder);
 		 Thread t = new Thread(inScript);
 		 t.start();
 		 
//       DaContext dc = new DaContext(holder);
//       dc.setFillStyle(255, 255, 255, 1);
//       dc.fillRect(22, 33, 300, 400);
//        Canvas canvas = holder.lockCanvas();
//
//        Paint paint = new Paint();
//        paint.setColor(Color.RED);
//        RectF r = new RectF(1,2, 222, 333);
//        canvas.drawRect(r, paint);
//        holder.unlockCanvasAndPost(canvas);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){
//        render.isRun = true;
//        render.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){

    }

//    class RenderThread extends Thread{
//        private SurfaceHolder holder;
//        public boolean isRun;
//
//        public RenderThread(SurfaceHolder holder){
//            this.holder = holder;
//            isRun = true;
//        }
//
//        @Override
//        public void run(){
//            String script1 = getFromeFile("Canvas.js");
//            String script2 = getFromeFile("index.js");
//            String script = script1 + script2;
//            org.mozilla.javascript.Context jsCx = org.mozilla.javascript.Context.enter();
//            jsCx.setOptimizationLevel(-1);
//            Scriptable scope = jsCx.initStandardObjects();
//            ScriptableObject.putProperty(scope, "DaContext", org.mozilla.javascript.Context.javaToJS(dc, scope));
//            jsCx.evaluateString(scope, script, "NativeHtml", 1, null);
//        }
//    }
}
