
define("index",['Canvas'], function(Canvas) {

	var ctx = Canvas.getContext('2d');

	ctx.fillStyle="#00ff00";
	ctx.fillRect(10, 300, 200, 200);
});

