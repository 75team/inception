define(['base'], function(base) {
    return {
        show: function(str) {
            base.alert(str);
        }
    }
});