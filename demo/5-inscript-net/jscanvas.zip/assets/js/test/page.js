//defineClass('com.chajn.jstest.InFile');
//
//var file = new InFile("myfile.txt");
//
//file.writeLine("one"); 
//file.writeLine("two");
//file.writeLine("thr", "ee");
//file.close();
define(['data', 'ui'], function(data, ui) {
    var str = data.users.join(',');
    ui.show(str);
});