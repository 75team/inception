var global = this;
	
this.log = function(text){
	java.lang.System.out.println(text);
}
log(1111);
//var requirejs = new Require('/resource/js/',{
//	base:'test/base',
//	data:'test/data',
//	page:'test/page',
//	ui:'test/ui'
//});
//var define = requirejs.define;
////log(requirejs);
//
////
//
//var requirejs = (function(){
//	var option;
//	function config(opt){
//		option = opt;
//	}
//	function define(mIds, callback){
//		for(var i=0;i<mIds.length;i++){
//			var id = mIds[i];
//			if(option.paths[id]){
//				var url = option.baseUrl + option.paths[id] + '.js';
//				loadjs(url);
//			}
//		}		
//	}
//	
//	
//	return {
//		config:config,
//		define:define
//	}
//})();

//requirejs.config({
//  baseUrl: 'resource/js/',
//  paths: {
//  	base:'test/base',
//  	data:'test/data',
//  	page:'test/page',
//  	ui:'test/ui'
//  }	
//})
//
//define(['data', 'ui'], function(data, ui) {
//	var str = data.user.join(',');
//	ui.show(str);
//});


//java.lang.System.out.println(global.parseInt("22"));



//requirejs.config({
//    baseUrl: 'resource/js/',
//    paths: {
//    	base:'test/base',
//    	data:'test/data',
//    	page:'test/page',
//    	ui:'test/ui'
//    }
//});

//var define = global.define;

//define(['data', 'ui'], function(data, ui) {
//    var str = data.user.join(',');
//    ui.show(str);
//});
//
//global.log(define,[111,222],{333:444},function(){global.log(121)});