define({
    users: ['chajn','curry'],
    members: ['admin']
});