define(function() {
    return {
    	alert:function(str){
    		print(str);
    	},
        mix: function(source, target) {
        	for(var property in source){
        		target[property] = source[property];
        	}
        	return target;
        }
    };
});