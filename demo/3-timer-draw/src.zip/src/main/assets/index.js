var ctx = Canvas.getContext('2d');
var width = Canvas.width,
    height = Canvas.height;

function log(str){
    Packages.android.util.Log.i("info", str);
}

ctx.fillStyle="#ff0000";
log(width+'  '+height);
ctx.fillRect(0, 0, width, height);

function t1(){
    ctx.fillStyle="#ff0000";
    ctx.fillRect(600, 200, 100, 100);
    ctx.fillStyle="#ffff00";
    ctx.fillRect(100, 200, 100, 100);
    setTimeout(t2, 500);
}
function t2(){
    ctx.fillStyle="#ff0000";
    ctx.fillRect(100, 200, 100, 100);
    ctx.fillStyle="#00ff00";
    ctx.fillRect(600, 200, 100, 100);
    setTimeout(t1, 500);
}
t1();