var ctx = Canvas.getContext('2d');

ctx.fillStyle="#ff0000";
ctx.fillRect(10, 300, 200, 200);