package org.qiwoo.inception.democanvasdraw;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import org.apache.http.util.EncodingUtils;
import org.mozilla.javascript.*;

import java.io.InputStream;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        InView view = new InView(this);
        setContentView(view);
    }

    class InView extends SurfaceView implements SurfaceHolder.Callback, Runnable{
        private SurfaceHolder holder;
        Thread jsRunner;
        Boolean isRun = false;
        private Context context;
        public InView(Context context){
            super(context);
            this.context = context;
            holder = getHolder();
            holder.addCallback(this);
            jsRunner = new Thread(this);
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder){
            if(!isRun) {
                isRun = true;
                jsRunner.start();
            }
            Log.i("info", "surface created");
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){
            //render.isRun = true;

        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder){

        }

        private String getFromeFile(String fileName) {
            String result = "";
            try{
                InputStream in = getResources().getAssets().open(fileName);
                int len = in.available();
                byte[] buffer = new byte[len];
                in.read(buffer);
                result = EncodingUtils.getString(buffer, "UTF-8");
            }catch (Exception e){
                e.printStackTrace();
            }
            return result;
        }
        @Override
        public void run(){
            String[] files = {"Color.js","Canvas.js","index.js"};

            org.mozilla.javascript.Context jsCx = org.mozilla.javascript.Context.enter();
            jsCx.setOptimizationLevel(-1);
            Scriptable scope = jsCx.initStandardObjects();
            InContext inContext = new InContext(holder);
            ScriptableObject.putProperty(scope, "inContext", org.mozilla.javascript.Context.javaToJS(inContext, scope));
            for(int i=0;i<files.length;i++){
                String fname = files[i];
                String script = getFromeFile(fname);
                jsCx.evaluateString(scope, script, fname, 1, null);
            }
        }
    }
}
