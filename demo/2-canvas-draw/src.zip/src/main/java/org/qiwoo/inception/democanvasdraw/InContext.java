package org.qiwoo.inception.democanvasdraw;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;

/**
 * Created by liupengke on 15/3/25.
 */
public class InContext {
    private Paint paint;
    private SurfaceHolder holder;

    public InContext(SurfaceHolder holder){
        this.holder = holder;
        paint = new Paint();
        paint.setColor(Color.BLACK);

    }
    public void setFillStyle(int a, int r, int g, int b){
        paint.setARGB(a, r, g, b);
    }
    public void fillRect(float x, float y, float w, float h){
        Canvas canvas = holder.lockCanvas();
        canvas.drawRect(x, y, x+w, y+h, paint);
        holder.unlockCanvasAndPost(canvas);
    }
}
